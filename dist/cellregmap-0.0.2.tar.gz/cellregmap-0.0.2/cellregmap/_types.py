from enum import Enum

__all__ = ["Term"]


class Term(Enum):
    FIXED = 1
    RANDOM = 2
